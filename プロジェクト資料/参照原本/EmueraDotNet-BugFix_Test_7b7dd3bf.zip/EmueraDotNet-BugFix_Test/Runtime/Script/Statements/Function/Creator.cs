﻿using MinorShift.Emuera.Runtime.Config;
using MinorShift.Emuera.Runtime.Script.Data;
using MinorShift.Emuera.Runtime.Script.Statements.Function;
using MinorShift.Emuera.Runtime.Utils;
using System.Collections.Generic;
using System.Drawing;


namespace MinorShift.Emuera.GameData.Function;

internal static partial class FunctionMethodCreator
{
    static FunctionMethodCreator()
    {
        methodList = new Dictionary<string, FunctionMethod>(Config.StrComper)
        {
            //キャラクタデータ系
            ["GETCHARA"] = new GetcharaMethod(),
            ["GETSPCHARA"] = new GetspcharaMethod(),
            ["CSVNAME"] = new CsvStrDataMethod(CharacterStrData.NAME),
            ["CSVCALLNAME"] = new CsvStrDataMethod(CharacterStrData.CALLNAME),
            ["CSVNICKNAME"] = new CsvStrDataMethod(CharacterStrData.NICKNAME),
            ["CSVMASTERNAME"] = new CsvStrDataMethod(CharacterStrData.MASTERNAME),
            ["CSVCSTR"] = new CsvcstrMethod(),
            ["CSVBASE"] = new CsvDataMethod(CharacterIntData.BASE),
            ["CSVABL"] = new CsvDataMethod(CharacterIntData.ABL),
            ["CSVMARK"] = new CsvDataMethod(CharacterIntData.MARK),
            ["CSVEXP"] = new CsvDataMethod(CharacterIntData.EXP),
            ["CSVRELATION"] = new CsvDataMethod(CharacterIntData.RELATION),
            ["CSVTALENT"] = new CsvDataMethod(CharacterIntData.TALENT),
            ["CSVCFLAG"] = new CsvDataMethod(CharacterIntData.CFLAG),
            ["CSVEQUIP"] = new CsvDataMethod(CharacterIntData.EQUIP),
            ["CSVJUEL"] = new CsvDataMethod(CharacterIntData.JUEL),
            ["GETCSVNOBYNAME"] = new GetCsvNoMethod(CharacterStrData.NAME),
            ["GETCSVNOBYNICKNAME"] = new GetCsvNoMethod(CharacterStrData.NICKNAME),
            ["GETCSVNOBYCALLNAME"] = new GetCsvNoMethod(CharacterStrData.CALLNAME),
            ["GETCSVNOBYMASTERNAME"] = new GetCsvNoMethod(CharacterStrData.MASTERNAME),
            ["FINDCHARA"] = new FindcharaMethod(false),
            ["FINDLASTCHARA"] = new FindcharaMethod(true),
            ["EXISTCSV"] = new ExistCsvMethod(),

            //汎用処理系
            ["VARSIZE"] = new VarsizeMethod(),
            ["CHKFONT"] = new CheckfontMethod(),
            ["CHKDATA"] = new CheckdataMethod(EraSaveFileType.Normal),
            ["ISSKIP"] = new IsSkipMethod(),
            ["MOUSESKIP"] = new MesSkipMethod(true),
            ["MESSKIP"] = new MesSkipMethod(false),
            ["GETCOLOR"] = new GetColorMethod(false),
            ["GETDEFCOLOR"] = new GetColorMethod(true),
            ["GETFOCUSCOLOR"] = new GetFocusColorMethod(),
            ["GETBGCOLOR"] = new GetBGColorMethod(false),
            ["GETDEFBGCOLOR"] = new GetBGColorMethod(true),
            ["GETSTYLE"] = new GetStyleMethod(),
            ["GETFONT"] = new GetFontMethod(),
            ["BARSTR"] = new BarStringMethod(),
            ["CURRENTALIGN"] = new CurrentAlignMethod(),
            ["CURRENTREDRAW"] = new CurrentRedrawMethod(),
            ["COLOR_FROMNAME"] = new ColorFromNameMethod(),
            ["COLOR_FROMRGB"] = new ColorFromRGBMethod(),

            //TODO:1810
            //methodList["CHKVARDATA"] = new CheckdataStrMethod(EraSaveFileType.Var);
            ["CHKCHARADATA"] = new CheckdataStrMethod(EraSaveFileType.CharVar),
            //methodList["CHKGLOBALDATA"] = new CheckdataMethod(EraSaveFileType.Global);
            //methodList["FIND_VARDATA"] = new FindFilesMethod(EraSaveFileType.Var);
            ["FIND_CHARADATA"] = new FindFilesMethod(EraSaveFileType.CharVar),

            //定数取得
            ["MONEYSTR"] = new MoneyStrMethod(),
            ["PRINTCPERLINE"] = new GetPrintCPerLineMethod(),
            ["PRINTCLENGTH"] = new PrintCLengthMethod(),
            ["SAVENOS"] = new GetSaveNosMethod(),
            ["GETTIME"] = new GettimeMethod(),
            ["GETTIMES"] = new GettimesMethod(),
            ["GETMILLISECOND"] = new GetmsMethod(),
            ["GETSECOND"] = new GetSecondMethod(),

            //数学関数
            ["RAND"] = new RandMethod(),
            ["MIN"] = new MaxMethod(false),
            ["MAX"] = new MaxMethod(true),
            ["ABS"] = new AbsMethod(),
            ["POWER"] = new PowerMethod(),
            ["SQRT"] = new SqrtMethod(),
            ["CBRT"] = new CbrtMethod(),
            ["LOG"] = new LogMethod(),
            ["LOG10"] = new LogMethod(10.0d),
            ["EXPONENT"] = new ExpMethod(),
            ["SIGN"] = new SignMethod(),
            ["LIMIT"] = new GetLimitMethod(),

            //変数操作系
            ["SUMARRAY"] = new SumArrayMethod(),
            ["SUMCARRAY"] = new SumArrayMethod(true),
            ["MATCH"] = new MatchMethod(),
            ["CMATCH"] = new MatchMethod(true),
            ["GROUPMATCH"] = new GroupMatchMethod(),
            ["NOSAMES"] = new NosamesMethod(),
            ["ALLSAMES"] = new AllsamesMethod(),
            ["MAXARRAY"] = new MaxArrayMethod(),
            ["MAXCARRAY"] = new MaxArrayMethod(true),
            ["MINARRAY"] = new MaxArrayMethod(false, false),
            ["MINCARRAY"] = new MaxArrayMethod(true, false),
            ["GETBIT"] = new GetbitMethod(),
            ["GETNUM"] = new GetnumMethod(),
            ["GETPALAMLV"] = new GetPalamLVMethod(),
            ["GETEXPLV"] = new GetExpLVMethod(),
            ["FINDELEMENT"] = new FindElementMethod(false),
            ["FINDLASTELEMENT"] = new FindElementMethod(true),
            ["INRANGE"] = new InRangeMethod(),
            ["INRANGEARRAY"] = new InRangeArrayMethod(),
            ["INRANGECARRAY"] = new InRangeArrayMethod(true),
            ["GETNUMB"] = new GetnumBMethod(),

            ["ARRAYMSORT"] = new ArrayMultiSortMethod(),

            //文字列操作系
            ["STRLENS"] = new StrlenMethod(),
            ["STRLENSU"] = new StrlenuMethod(),
            ["SUBSTRING"] = new SubstringMethod(),
            ["SUBSTRINGU"] = new SubstringuMethod(),
            ["STRFIND"] = new StrfindMethod(false),
            ["STRFINDU"] = new StrfindMethod(true),
            ["STRCOUNT"] = new StrCountMethod(),
            ["TOSTR"] = new ToStrMethod(),
            ["TOINT"] = new ToIntMethod(),
            ["TOUPPER"] = new StrChangeStyleMethod(StrFormType.Upper),
            ["TOLOWER"] = new StrChangeStyleMethod(StrFormType.Lower),
            ["TOHALF"] = new StrChangeStyleMethod(StrFormType.Half),
            ["TOFULL"] = new StrChangeStyleMethod(StrFormType.Full),
            ["LINEISEMPTY"] = new LineIsEmptyMethod(),
            ["REPLACE"] = new ReplaceMethod(),
            ["UNICODE"] = new UnicodeMethod(),
            ["UNICODEBYTE"] = new UnicodeByteMethod(),
            ["CONVERT"] = new ConvertIntMethod(),
            ["ISNUMERIC"] = new IsNumericMethod(),
            ["ESCAPE"] = new EscapeMethod(),
            ["ENCODETOUNI"] = new EncodeToUniMethod(),
            ["CHARATU"] = new CharAtMethod(),
            ["GETLINESTR"] = new GetLineStrMethod(),
            ["STRFORM"] = new StrFormMethod(),
            ["STRJOIN"] = new JoinMethod(),

            ["GETCONFIG"] = new GetConfigMethod(true),
            ["GETCONFIGS"] = new GetConfigMethod(false),

            //html系
            ["HTML_GETPRINTEDSTR"] = new HtmlGetPrintedStrMethod(),
            ["HTML_POPPRINTINGSTR"] = new HtmlPopPrintingStrMethod(),
            ["HTML_TOPLAINTEXT"] = new HtmlToPlainTextMethod(),
            ["HTML_ESCAPE"] = new HtmlEscapeMethod(),


            //画像処理系
            ["SPRITECREATED"] = new SpriteStateMethod(),
            ["SPRITEWIDTH"] = new SpriteStateMethod(),
            ["SPRITEHEIGHT"] = new SpriteStateMethod(),
            ["SPRITEMOVE"] = new SpriteSetPosMethod(),
            ["SPRITESETPOS"] = new SpriteSetPosMethod(),
            ["SPRITEPOSX"] = new SpriteStateMethod(),
            ["SPRITEPOSY"] = new SpriteStateMethod(),

            ["CLIENTWIDTH"] = new ClientSizeMethod(),
            ["CLIENTHEIGHT"] = new ClientSizeMethod(),

            ["GETKEY"] = new GetKeyStateMethod(),
            ["GETKEYTRIGGERED"] = new GetKeyStateMethod(),
            ["MOUSEX"] = new MousePosMethod(),
            ["MOUSEY"] = new MousePosMethod(),
            ["ISACTIVE"] = new IsActiveMethod(),
            ["SAVETEXT"] = new SaveTextMethod(),
            ["LOADTEXT"] = new LoadTextMethod(),

            ["GCREATED"] = new GraphicsStateMethod(),// ("GCREATED");
            ["GWIDTH"] = new GraphicsStateMethod(),//("GWIDTH");
            ["GHEIGHT"] = new GraphicsStateMethod(),//("GHEIGHT");
            ["GGETCOLOR"] = new GraphicsGetColorMethod(),
            ["SPRITEGETCOLOR"] = new SpriteGetColorMethod(),

            ["GCREATE"] = new GraphicsCreateMethod(),
            ["GCREATEFROMFILE"] = new GraphicsCreateFromFileMethod(),
            ["GDISPOSE"] = new GraphicsDisposeMethod(),
            ["GCLEAR"] = new GraphicsClearMethod(),
            ["GFILLRECTANGLE"] = new GraphicsFillRectangleMethod(),

            ["G_POLYGON_DRAW"] = new GraphicsDrawPolygonMethod(),
            ["G_POLYGON_FILL"] = new GraphicsFillPolygonMethod(),
            ["G_POLYGON_POINT_ADD"] = new GraphicsPolygonPointAddMethod(),
            ["G_POLYGON_POINT_CLEAR"] = new GraphicsPolygonPointClearMethod(),

            ["GDRAWTEXT"] = new GraphicsDrawTextMethod(),

            ["GDRAWSPRITE"] = new GraphicsDrawSpriteMethod(),
            ["GSETCOLOR"] = new GraphicsSetColorMethod(),
            ["GDRAWG"] = new GraphicsDrawGMethod(),
            ["GDRAWGWITHMASK"] = new GraphicsDrawGWithMaskMethod(),

            ["GSETBRUSH"] = new GraphicsSetBrushMethod(),
            ["GSETFONT"] = new GraphicsSetFontMethod(),
            ["GSETPEN"] = new GraphicsSetPenMethod(),

            ["SPRITECREATE"] = new SpriteCreateMethod(),
            ["SPRITEDISPOSE"] = new SpriteDisposeMethod(),

            ["CBGSETG"] = new CBGSetGraphicsMethod(),
            ["CBGSETSPRITE"] = new CBGSetCIMGMethod(),
            ["CBGCLEAR"] = new CBGClearMethod(),

            ["CBGCLEARBUTTON"] = new CBGClearButtonMethod(),
            ["CBGREMOVERANGE"] = new CBGRemoveRangeMethod(),
            ["CBGREMOVEBMAP"] = new CBGRemoveBMapMethod(),
            ["CBGSETBMAPG"] = new CBGSetBMapGMethod(),
            ["CBGSETBUTTONSPRITE"] = new CBGSETButtonSpriteMethod(),

            ["GSAVE"] = new GraphicsSaveMethod(),
            ["GLOAD"] = new GraphicsLoadMethod(),


            ["SPRITEANIMECREATE"] = new SpriteAnimeCreateMethod(),
            ["SPRITEANIMEADDFRAME"] = new SpriteAnimeAddFrameMethod(),
            ["SETANIMETIMER"] = new SetAnimeTimerMethod(),

            ["SQL_CONNECTION_OPEN"] = new SQLConnectionOpen(),
            ["SQL_EXECUTE_READER"] = new SQLExecuteReader(),
            ["SQL_EXECUTE_SCALER_LONG"] = new SQLExecuteScalerLong(),
            ["SQL_EXECUTE_SCALER_STRING"] = new SQLExecuteScalerStr(),
            ["SQL_EXECUTE_NONQUERY"] = new SQLExecuteNonQuery(),
            ["SQL_READER_READ"] = new SQLReaderRead(),
            ["SQL_READER_GET_LONG"] = new SQLReaderGetLong(),
            ["SQL_READER_GET_STRING"] = new SQLReaderGetString(),
            ["SQL_READER_IS_NULL"] = new SQLReaderIsNull(),

            ["HASH_XXH3"] = new XXH3(),
            ["HASH_XXH32"] = new XXH32(),

            ["EXISTFUNCTION"] = new EXISTFUNCTION(),

            ["DICT_CREATE"] = new DictCreate(),
            ["DICT_EXIST"] = new DictExist(),
            ["DICT_CONTAINS_KEY"] = new DictContainsKey(),
            ["DICT_SET_VALUE"] = new DictSetValue(),
            ["DICT_GET_VALUE_STRING"] = new DictGetValueString(),
            ["DICT_GET_VALUE_LONG"] = new DictGetValueInt()
        };


        //1823 自分の関数名を知っていた方が何かと便利なので覚えさせることにした
        foreach (var pair in methodList)
            pair.Value.SetMethodName(pair.Key);
    }

    private static readonly Dictionary<string, FunctionMethod> methodList;
    public static Dictionary<string, FunctionMethod> GetMethodList()
    {
        return methodList;
    }
}
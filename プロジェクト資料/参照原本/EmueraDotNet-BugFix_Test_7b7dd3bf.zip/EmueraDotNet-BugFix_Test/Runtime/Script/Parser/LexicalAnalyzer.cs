﻿using MinorShift.Emuera.Runtime.Config;
using MinorShift.Emuera.Runtime.Script.Data;
using MinorShift.Emuera.Runtime.Script.Statements.Expression;
using MinorShift.Emuera.Runtime.Utils;
using System;
using System.Buffers;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using MinorShift.Emuera.UI.Framework;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MinorShift.Emuera.Runtime.Script.Parser;

enum LexEndWith
{
    //いずれにせよEoLで強制終了
    None = 0,
    EoL,//常に最後まで解析
    Operator,//演算子を見つけたら終了。代入式の左辺
    Question,//三項演算子?により終了。\@～～?～～#～～\@
    Percent,//%により終了。%～～%
    RightCurlyBrace,//}により終了。{～～}
    Comma,//,により終了。TIMES第一引数
          //Single,//Identifier一つで終了//1807 Single削除
    GreaterThan,//'>'により終了。Htmlタグ解析
}

enum FormStrEndWith
{
    //いずれにせよEoLで強制終了
    None = 0,
    EoL,//常に最後まで解析
    DoubleQuotation,//"で終了。@"～～"
    Sharp,//#で終了。\@～～?～～#～～\@　の一つ目
    YenAt,//\@で終了。\@～～?～～#～～\@　の二つ目
    Comma,//,により終了。ANY_FORM引数
    LeftParenthesis_Bracket_Comma_Semicolon,//[または(または,または;により終了。CALLFORM系の関数名部分。
}

enum StrEndWith
{
    //いずれにせよEoLで強制終了
    None = 0,
    EoL,//常に最後まで解析
    SingleQuotation,//"で終了。'～～'
    DoubleQuotation,//"で終了。"～～"
    Comma,//,により終了。PRINTV'～～,
    LeftParenthesis_Bracket_Comma_Semicolon,//[または(または,または;により終了。関数名部分。
}

enum LexAnalyzeFlag
{
    None = 0,
    AnalyzePrintV = 1,//PRINTVの引数で'に続けて文字列を書くと数式ではないが文字列として表示される
    AllowAssignment = 2,//代入演算子が使用できる場面であるFlag。このFlagなしで=が途中に出てきたらエラー
    AllowSingleQuotationStr = 4,//HTML_PRINT解析用。''で囲まれた文字列を許可する。
}

/// <summary>
/// 1756 TokenReaderより改名
/// Lexicalといいつつ構文解析を含む
/// </summary>
internal static partial class LexicalAnalyzer
{

    const int MAX_EXPAND_MACRO = 100;
    //readonly static IList<char> operators = new char[] { '+', '-', '*', '/', '%', '=', '!', '<', '>', '|', '&', '^', '~', '?', '#' };
    //readonly static IList<char> whiteSpaces = new char[] { ' ', '　', '\t' };
    //readonly static IList<char> endOfExpression = new char[] { ')', '}', ']', ',', ':' };
    //readonly static IList<char> startOfExpression = new char[] { '(' };
    //readonly static IList<char> stringToken = new char[] { '\"', };
    //readonly static IList<char> stringFormToken = new char[] { '@', };
    //readonly static IList<char> etcSymbol = new char[] { '[', '{', '$', '\\', };
    //readonly static IList<char> decimalDigits = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', };
    readonly static char[] hexadecimalDigits = ['a', 'b', 'c', 'd', 'e', 'f', 'A', 'B', 'C', 'D', 'E', 'F'];

    //1819 正規表現使うとやや遅い。いずれdoubleにも対応させたい。そのうち考える
    //readonly static Regex DigitsReg = new Regex("" +
    //	"(" +
    //	"((?<simple>[-]?[0-9]+)([^.xXbBeEpP]|$))" +
    //	"|(" +
    //	"(0(x|X)(?<hex>[0-9a-fA-F]+))|"+
    //	"(0(b|B)(?<bin>[01]+))|"+
    //	"(" + //base10
    //	"(?<integer>[-]?[0-9]*(?<double>[.][0-9])?)" +
    //	"(((p|P)(?<exp2>[0-9]+))|" +
    //	"((e|E)(?<exp10>[0-9]+)))?" +
    //	")"+
    //	"))"
    //	, RegexOptions.Compiled);
    //readonly static Regex idReg = new Regex(@"[^][ \t+*/%=!<>|&^~?#(){},:$\\'""@.;　-]+", RegexOptions.Compiled);
    //public static Int64 ReadInt64(StringStream st, bool retZero)
    //{
    //	Match m = DigitsReg.Match(st.RowString, st.CurrentPosition);
    //	string numstr = m.Groups["simple"].Value;
    //	if (numstr.Length > 0)
    //	{
    //		st.Jump(numstr.Length);
    //		return Convert.ToInt64(numstr, 10);
    //	}
    //	st.Jump(m.Length);
    //	if (m.Groups["bin"].Length > 0)
    //		return Convert.ToInt64(m.Groups["bin"].Value, 2);
    //	if(m.Groups["hex"].Length > 0)
    //		return Convert.ToInt64(m.Groups["hex"].Value, 16);
    //	numstr = m.Groups["number"].Value;
    //	if (numstr.Length > 0)
    //	{
    //		int exp = 0;
    //		string exp2 = m.Groups["exp2"].Value;
    //		string exp10 = m.Groups["exp10"].Value;
    //		if(m.Groups["double"].Length == 0 && exp2.Length == 0 && exp10.Length == 0)
    //		{
    //			return Convert.ToInt64(numstr,10);
    //		}
    //		double d = Convert.ToDouble(numstr);
    //		if (exp2.Length > 0)
    //		{
    //			exp = Convert.ToInt32(exp2, 10);
    //			d = d * Math.Pow(2, exp);
    //		}
    //		else if (exp10.Length > 0)
    //		{
    //			exp = Convert.ToInt32(exp10, 10);
    //			d = d * Math.Pow(10, exp);
    //		}
    //		return ((Int64)(d + 0.49));
    //	}
    //	throw new CodeEE("数字で始まるトークンが適切でありません");
    //}



    public static bool UseMacro = true;
    #region read
    public static long ReadInt64(CharStream st, bool retZero)
    {
        long significand;
        int expBase = 0;
        int exponent = 0;
        int stStartPos = st.CurrentPosition;
        int stEndPos;
        int fromBase = 10;
        if (st.Current == '0')
        {
            char c = st.Next;
            if (c == 'x' || c == 'X')
            {
                fromBase = 16;
                st.ShiftNext();
                st.ShiftNext();
            }
            else if (c == 'b' || c == 'B')
            {
                fromBase = 2;
                st.ShiftNext();
                st.ShiftNext();
            }
            //8進法は互換性の問題から採用しない。
            //else if (dchar.IsDigit(c))
            //{
            //    fromBase = 8;
            //    st.ShiftNext();
            //}
        }
        if (retZero && st.Current != '+' && st.Current != '-' && !char.IsDigit(st.Current))
        {
            if (fromBase != 16)
                return 0;
            else if (!hexadecimalDigits.AsSpan().Contains(st.Current))
                return 0;
        }
        significand = readDigits(st, fromBase);
        if (st.Current == 'p' || st.Current == 'P')
            expBase = 2;
        else if (st.Current == 'e' || st.Current == 'E')
            expBase = 10;
        if (expBase != 0)
        {
            st.ShiftNext();
            unchecked { exponent = (int)readDigits(st, fromBase); }
        }
        stEndPos = st.CurrentPosition;
        if (expBase != 0 && exponent != 0)
        {

            double d = significand * Math.Pow(expBase, exponent);
            if (double.IsNaN(d) || double.IsInfinity(d) || d > long.MaxValue || d < long.MinValue)
                throw new CodeEE(string.Format(LocalizationManager.Error.OoRInt64, st.Substring(stStartPos, stEndPos)));
            significand = (long)d;
        }
        return significand;
    }

    //IsNumericにReadInt64を使うと、本来falseになるべき文字列の一部がCodeEEになってしまうので、新規に追加
    public static bool NumericCheck(CharStream st)
    {
        Int64 significand;
        int expBase = 0;
        int exponent = 0;
        int stStartPos = st.CurrentPosition;
        int stEndPos;
        int fromBase = 10;
        if (st.Current == '0')
        {
            char c = st.Next;
            if ((c == 'x') || (c == 'X'))
            {
                fromBase = 16;
                st.ShiftNext();
                st.ShiftNext();
            }
            else if ((c == 'b') || (c == 'B'))
            {
                fromBase = 2;
                st.ShiftNext();
                st.ShiftNext();
            }
        }
        if (st.Current != '+' && st.Current != '-' && !char.IsDigit(st.Current))
        {
            if (fromBase != 16)
                return false;
            //else if (!hexadecimalDigits.Contains(st.Current))
            else if (0 <= Array.IndexOf(hexadecimalDigits, st.Current))
                return false;
        }
        // ここでエラーが発生する場合、そもそも文字列ではないのでfalseを返す
        try
        {
            significand = readDigits(st, fromBase);
        }
        catch (CodeEE)
        {
            return false;
        }
        if ((st.Current == 'p') || (st.Current == 'P'))
            expBase = 2;
        else if ((st.Current == 'e') || (st.Current == 'E'))
            expBase = 10;
        if (expBase != 0)
        {
            st.ShiftNext();
            if (st.EOS || !char.IsDigit(st.Current))
                return false;
            unchecked { exponent = (int)readDigits(st, fromBase); }
        }
        stEndPos = st.CurrentPosition;
        if ((expBase != 0) && (exponent != 0))
        {

            double d = significand * Math.Pow(expBase, exponent);
            if ((double.IsNaN(d)) || (double.IsInfinity(d)) || (d > Int64.MaxValue) || (d < Int64.MinValue))
                throw new CodeEE("\"" + st.Substring(stStartPos, stEndPos) + "\"は64ビット符号付整数の範囲を超えています");
        }

        return true;
    }


    static readonly SearchValues<char> digit = SearchValues.Create(['0','1','2','3','4','5','6','7','8','9',
                                                        'a', 'b', 'c', 'd', 'e', 'f',
                                                        'A', 'B', 'C', 'D', 'E', 'F']);
    private static long readDigits(CharStream st, int fromBase)
    {
        var span = st.SubstringROS();

        var searchStart = 0;
        // "+"、"-"の符号が先頭につく場合、開始位置を符号の次の文字に設定する、
        if (span[0] == '-' || span[0] == '+')
        {
            searchStart = 1;
        }

        var end = span[searchStart..].IndexOfAnyExcept(digit);
        if (end == -1)
        {
            end = searchStart + span.Length;
            // "+"、"-"の符号が先頭につく場合、符号以降の文字数を取得する、
            if (span[0] == '-' || span[0] == '+')
            {
                end -= 1;
            }
        }
        st.Jump(end);

        var integerSpan = span[..end];

        try
        {
            if (fromBase == 10)
            {
                return long.Parse(integerSpan, NumberStyles.AllowLeadingSign | NumberStyles.AllowExponent);
            }
            if (fromBase == 16)
            {
                return long.Parse(integerSpan, NumberStyles.HexNumber);
            }
            if (fromBase == 2)
            {
                return long.Parse(integerSpan, NumberStyles.BinaryNumber);
            }
            return Convert.ToInt64(integerSpan.ToString(), fromBase);
        }
        catch (FormatException)
        {
            throw new CodeEE(string.Format(LocalizationManager.Error.CanNotConvertToInt, integerSpan.ToString()));
        }
        catch (OverflowException)
        {
            throw new CodeEE(string.Format(LocalizationManager.Error.OoRInt64, integerSpan.ToString()));
        }
        catch (ArgumentOutOfRangeException)
        {
            if (integerSpan.IsEmpty)
                throw new CodeEE(LocalizationManager.Error.CanNotInterpretNum);
            throw new CodeEE(string.Format(LocalizationManager.Error.CanNotInterpretNumValue, integerSpan.ToString()));
        }
    }

    /// <summary>
    /// TIMES第二引数のみが使用する。
    /// Convertクラスが発行する例外をそのまま投げるので適切に処理すること。
    /// </summary>
    /// <param name="st"></param>
    /// <returns></returns>
    public static double ReadDouble(CharStream st)
    {
        int start = st.CurrentPosition;
        //大雑把に読み込んでエラー処理はConvertクラスに任せる。
        //仮数小数部

        if (st.Current == '-' || st.Current == '+')
        {
            st.ShiftNext();
        }
        while (!st.EOS)
        {//仮数部
            char c = st.Current;
            if (char.IsDigit(c) || c == '.')
            {
                st.ShiftNext();
                continue;
            }
            break;
        }
        if (st.Current == 'e' || st.Current == 'E')
        {
            st.ShiftNext();
            if (st.Current == '-')
            {
                st.ShiftNext();
            }
            while (!st.EOS)
            {//指数部
                char c = st.Current;
                if (char.IsDigit(c) || c == '.')
                {
                    st.ShiftNext();
                    continue;
                }
                break;
            }
        }



        return double.Parse(st.SubstringROS(start, st.CurrentPosition - start), CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// 行頭の単語の取得。マクロ展開あり。ただし単語でないマクロ展開はしない。
    /// </summary>
    /// <param name="st"></param>
    /// <returns></returns>
    public static IdentifierWord ReadFirstIdentifierWord(CharStream st)
    {
        //int startpos = st.CurrentPosition;
        var str = ReadSingleIdentifierROS(st);
        if (str.IsEmpty)
            throw new CodeEE(LocalizationManager.Error.LineBeginsIllegalCharacter);
        //1808a3 先頭1単語の展開をやめる。－命令の置換を禁止。
        //if (UseMacro)
        //{
        //    int i = 0;
        //    while (true)
        //    {
        //        DefineMacro macro = GlobalStatic.IdentifierDictionary.GetMacro(str);
        //        i++;
        //        if (i > MAX_EXPAND_MACRO)
        //            throw new CodeEE("マクロの展開数が1文あたりの上限を超えました(自己参照・循環参照のおそれ)");
        //        if (macro == null)
        //            break;
        //        //単語（識別子一個）でないマクロが出現したらここでは処理しない
        //        if (macro.IDWord == null)
        //        {
        //            st.CurrentPosition = startpos;
        //            return null;//変数処理に任せる。
        //        }
        //        str = macro.IDWord.Code;
        //    }
        //}
        return new IdentifierWord(str.ToString());
    }

    /// <summary>
    /// 単語の取得。マクロ展開あり。関数型マクロ展開なし
    /// </summary>
    /// <param name="st"></param>
    /// <returns></returns>
    public static IdentifierWord ReadSingleIdentifierWord(CharStream st)
    {
        string str = ReadSingleIdentifier(st);
        if (string.IsNullOrEmpty(str))
            return null;
        if (UseMacro)
        {
            int i = 0;
            while (true)
            {
                DefineMacro macro = GlobalStatic.IdentifierDictionary.GetMacro(str);
                i++;
                if (i > MAX_EXPAND_MACRO)
                    throw new CodeEE(string.Format(LocalizationManager.Error.MacroOverLimit, MAX_EXPAND_MACRO.ToString()));
                if (macro == null)
                    break;
                if (macro.IDWord != null)
                    throw new CodeEE(string.Format(LocalizationManager.Error.MacroIsNotAvailable, macro.Keyword));
                str = macro.IDWord.Code;
            }
        }
        return new IdentifierWord(str);
    }

    /// <summary>
    /// 単語を文字列で取得。マクロ適用なし
    /// </summary>
    /// <param name="st"></param>
    /// <returns></returns>
    public static string ReadSingleIdentifier(CharStream st)
    {
        var span = ReadSingleIdentifierROS(st);
        return span.ToString(); ;
    }

    static readonly SearchValues<char> _searchValues = SearchValues.Create(""" 　.+-*/%=!<>|&^~?#)}],:({[$\'"@;""" + "\t");

    public static ReadOnlySpan<char> ReadSingleIdentifierROS(CharStream st)
    {
        var row = st.RowString.AsSpan()[st.CurrentPosition..];

        var index = row.IndexOfAny(_searchValues);
        if (index != -1)
        {
            st.Jump(index);
            return row[..index];
        }

        st.Jump(row.Length);
        return row;
    }


    /// <summary>
    /// endWithが見つかるまで読み込む。始点と終端のチェックは呼び出し側で行うこと。
    /// エスケープあり。
    /// </summary>
    /// <param name="st"></param>
    /// <returns></returns>
    public static string ReadString(CharStream st, StrEndWith endWith)
    {
        var buffer = new StringBuilder(st.RowString.Length - st.CurrentPosition);
        void loop()
        {
            while (true)
            {
                switch (st.Current)
                {
                    case '\0':
                        return;
                    case '\"':
                        if (endWith == StrEndWith.DoubleQuotation)
                            return;
                        break;
                    case '\'':
                        if (endWith == StrEndWith.SingleQuotation)
                            return;
                        break;
                    case ',':
                        if (endWith == StrEndWith.Comma || endWith == StrEndWith.LeftParenthesis_Bracket_Comma_Semicolon)
                            return;
                        break;
                    case '(':
                    case '[':
                    case ';':
                        if (endWith == StrEndWith.LeftParenthesis_Bracket_Comma_Semicolon)
                            return;
                        break;
                    case '\\'://エスケープ処理
                        st.ShiftNext();//\を読み飛ばす
                        switch (st.Current)
                        {
                            case CharStream.EndOfString:
                                throw new CodeEE(LocalizationManager.Error.MissingCharacterAfterEscape);
                            case '\n': break;
                            case 's': buffer.Append(' '); break;
                            case 'S': buffer.Append('　'); break;
                            case 't': buffer.Append('\t'); break;
                            case 'n': buffer.Append('\n'); break;
                            default: buffer.Append(st.Current); break;
                        }
                        st.ShiftNext();//\の次の文字を読み飛ばす
                        continue;
                }
                buffer.Append(st.Current);
                st.ShiftNext();
            }
        }
        loop();

        return buffer.ToString();
    }

    /// <summary>
    /// 失敗したらCodeEE。OperatorManagerには頼らない
    /// OperatorCode.Assignmentを返すことがある。
    /// </summary>
    /// <param name="st"></param>
    /// <returns></returns>
    public static OperatorCode ReadOperator(CharStream st, bool allowAssignment)
    {
        char cur = st.Current;
        st.ShiftNext();
        char next = st.Current;
        switch (cur)
        {
            case '+':
                if (next == '+')
                {
                    st.ShiftNext();
                    return OperatorCode.Increment;
                }
                return OperatorCode.Plus;
            case '-':
                if (next == '-')
                {
                    st.ShiftNext();
                    return OperatorCode.Decrement;
                }
                return OperatorCode.Minus;
            case '*':
                return OperatorCode.Mult;
            case '/':
                return OperatorCode.Div;
            case '%':
                return OperatorCode.Mod;
            case '=':
                if (next == '=')
                {
                    st.ShiftNext();
                    return OperatorCode.Equal;
                }
                if (allowAssignment)
                    return OperatorCode.Assignment;
                throw new CodeEE(LocalizationManager.Error.UnexpectedEqual);
            case '!':
                if (next == '=')
                {
                    st.ShiftNext();
                    return OperatorCode.NotEqual;
                }
                else if (next == '&')
                {
                    st.ShiftNext();
                    return OperatorCode.Nand;
                }
                else if (next == '|')
                {
                    st.ShiftNext();
                    return OperatorCode.Nor;
                }
                return OperatorCode.Not;
            case '<':
                if (next == '=')
                {
                    st.ShiftNext();
                    return OperatorCode.LessEqual;
                }
                else if (next == '<')
                {
                    st.ShiftNext();
                    return OperatorCode.LeftShift;
                }
                return OperatorCode.Less;
            case '>':
                if (next == '=')
                {
                    st.ShiftNext();
                    return OperatorCode.GreaterEqual;
                }
                else if (next == '>')
                {
                    st.ShiftNext();
                    return OperatorCode.RightShift;
                }
                return OperatorCode.Greater;
            case '|':
                if (next == '|')
                {
                    st.ShiftNext();
                    return OperatorCode.Or;
                }
                return OperatorCode.BitOr;
            case '&':
                if (next == '&')
                {
                    st.ShiftNext();
                    return OperatorCode.And;
                }
                return OperatorCode.BitAnd;
            case '^':
                if (next == '^')
                {
                    st.ShiftNext();
                    return OperatorCode.Xor;
                }
                return OperatorCode.BitXor;
            case '~':
                return OperatorCode.BitNot;
            case '?':
                return OperatorCode.Ternary_a;
            case '#':
                return OperatorCode.Ternary_b;

        }
        throw new CodeEE(string.Format(LocalizationManager.Error.CanNotRecognizedOp, cur));
    }

    /// <summary>
    /// 失敗したらCodeEE。OperatorManagerには頼らない
    /// "="の時、OperatorCode.Assignmentを返す。"=="の時はEqual
    /// </summary>
    /// <param name="st"></param>
    /// <returns></returns>
    public static OperatorCode ReadAssignmentOperator(CharStream st)
    {
        OperatorCode ret = OperatorCode.NULL;
        char cur = st.Current;
        st.ShiftNext();
        char next = st.Current;
        switch (cur)
        {
            case '+':
                if (next == '+')
                    ret = OperatorCode.Increment;
                else if (next == '=')
                    ret = OperatorCode.Plus;
                break;
            case '-':
                if (next == '-')
                    ret = OperatorCode.Decrement;
                else if (next == '=')
                    ret = OperatorCode.Minus;
                break;
            case '*':
                if (next == '=')
                    ret = OperatorCode.Mult;
                break;
            case '/':
                if (next == '=')
                    ret = OperatorCode.Div;
                break;
            case '%':
                if (next == '=')
                    ret = OperatorCode.Mod;
                break;
            case '=':
                if (next == '=')
                {
                    ret = OperatorCode.Equal;
                    break;
                }
                return OperatorCode.Assignment;
            case '\'':
                if (next == '=')
                {
                    ret = OperatorCode.AssignmentStr;
                    break;
                }
                throw new CodeEE(string.Format(LocalizationManager.Error.CanNotRecognizedAssignOp, "\'"));
            case '<':
                if (next == '<')
                {
                    st.ShiftNext();
                    if (st.Current == '=')
                    {
                        ret = OperatorCode.LeftShift;
                        break;
                    }
                    throw new CodeEE(string.Format(LocalizationManager.Error.CanNotRecognizedAssignOp, "<"));
                }
                break;
            case '>':
                if (next == '>')
                {
                    st.ShiftNext();
                    if (st.Current == '=')
                    {
                        ret = OperatorCode.RightShift;
                        break;
                    }
                    throw new CodeEE(string.Format(LocalizationManager.Error.CanNotRecognizedAssignOp, ">"));
                }
                break;
            case '|':
                if (next == '=')
                    ret = OperatorCode.BitOr;
                break;
            case '&':
                if (next == '=')
                    ret = OperatorCode.BitAnd;
                break;
            case '^':
                if (next == '=')
                    ret = OperatorCode.BitXor;
                break;
        }
        if (ret == OperatorCode.NULL)
            throw new CodeEE(string.Format(LocalizationManager.Error.CanNotRecognizedAssignOp, cur));
        st.ShiftNext();
        return ret;
    }



    /// <summary>
    /// Consoleの文字表示用。字句解析や構文解析に使ってはならない
    /// </summary>
    public static int SkipAllSpace(CharStream st)
    {
        int count = 0;
        while (true)
        {
            switch (st.Current)
            {
                case ' ':
                case '\t':
                case '　':
                    count++;
                    st.ShiftNext();
                    continue;
            }
            return count;
        }
    }

    public static bool IsWhiteSpace(char c)
    {
        return c == ' ' || c == '\t' || c == '　';
    }

    /// <summary>
    /// 字句解析・構文解析用。ホワイトスペースの他、コメントも飛ばす。
    /// </summary>
    public static int SkipWhiteSpace(CharStream st)
    {
        int count = 0;
        while (true)
        {
            switch (st.Current)
            {
                case ' ':
                case '\t':
                    count++;
                    st.ShiftNext();
                    continue;
                case '　':
                    if (!Config.Config.SystemAllowFullSpace)
                        return count;
                    goto case ' ';
                case ';':
                    if (st.CurrentEqualTo(";#;") && Program.DebugMode)
                    {
                        st.Jump(3);
                        continue;
                    }
                    else if (st.CurrentEqualTo(";!;"))
                    {
                        st.Jump(3);
                        continue;
                    }
                    st.Seek(0, System.IO.SeekOrigin.End);
                    return count;
            }
            return count;
        }
    }

    /// <summary>
    /// 字句解析・構文解析用。文字列直前の半角スペースを飛ばす。性質上、半角スペースのみを見る。
    /// </summary>
    public static int SkipHalfSpace(CharStream st)
    {
        int count = 0;
        while (st.Current == ' ')
        {
            count++;
            st.ShiftNext();
        }
        return count;
    }
    #endregion

    #region analyse

    /// <summary>
    /// 解析できるものは関数宣言や式のみ。FORM文字列や普通の文字列を送ってはいけない
    /// return時にはendWithの文字がCurrentになっているはず。終端の適切さの検証は呼び出し元が行う。
    /// </summary>
    /// <returns></returns>
    [MethodImpl(MethodImplOptions.AggressiveOptimization)]
    public static WordCollection Analyse(CharStream st, LexEndWith endWith, LexAnalyzeFlag flag)
    {
        var ret = new WordCollection();
        int nestBracketS = 0;
        //int nestBracketM = 0;
        int nestBracketL = 0;

        [MethodImpl(MethodImplOptions.AggressiveOptimization)]
        void local()
        {
            while (true)
            {
                switch (st.Current)
                {
                    case '\n':
                    case '\0':
                        return;
                    case ' ':
                    case '\t':
                        st.ShiftNext();
                        continue;
                    case '　':
                        if (!Config.Config.SystemAllowFullSpace)
                            throw new CodeEE(string.Format(LocalizationManager.Error.UnexpectedFullWidthSpace, Config.Config.GetConfigName(ConfigCode.SystemAllowFullSpace)));
                        st.ShiftNext();
                        continue;
                    case '0':
                    case '1':
                    case '2':
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                        ret.Add(new LiteralIntegerWord(ReadInt64(st, false)));
                        break;
                    case '>':
                        if (endWith == LexEndWith.GreaterThan)
                            return;
                        goto case '+';
                    case '+':
                    case '-':
                    case '*':
                    case '/':
                    case '%':
                    case '=':
                    case '!':
                    case '<':
                    case '|':
                    case '&':
                    case '^':
                    case '~':
                    case '?':
                    case '#':
                        if (nestBracketS == 0 && nestBracketL == 0)
                        {
                            if (endWith == LexEndWith.Operator)
                                return;//代入演算子のはずである。呼び出し元がチェックするはず
                            else if (endWith == LexEndWith.Percent && st.Current == '%')
                                return;
                            else if (endWith == LexEndWith.Question && st.Current == '?')
                                return;
                        }
                        ret.Add(new OperatorWord(ReadOperator(st, (flag & LexAnalyzeFlag.AllowAssignment) == LexAnalyzeFlag.AllowAssignment)));
                        break;
                    case ')': ret.Add(new SymbolWord(')')); nestBracketS--; st.ShiftNext(); continue;
                    case ']': ret.Add(new SymbolWord(']')); nestBracketL--; st.ShiftNext(); continue;
                    case '(': ret.Add(new SymbolWord('(')); nestBracketS++; st.ShiftNext(); continue;
                    case '[':
                        if (st.Next == '[')
                        {
                            //throw new CodeEE("字句解析中に予期しない文字'[['を発見しました");
                            ////1808alpha006 rename処理変更
                            //1808beta009 ここだけ戻す
                            //現在の処理だとここに来た時点でrename失敗確定だが警告内容を元に戻すため
                            if (ParserMediator.RenameDic == null)
                                throw new CodeEE(string.Format(LocalizationManager.Error.UnexpectedCharacter, "[["));
                            int start = st.CurrentPosition;
                            int find = st.Find("]]");
                            if (find <= 2)
                            {
                                if (find == 2)
                                    throw new CodeEE(LocalizationManager.Error.EmptyTwoSBrackets);
                                else
                                    throw new CodeEE(LocalizationManager.Error.MissingTwoSBrackets);
                            }
                            string key = st.Substring(start, find + 2);
                            //1810 ここまでで置換できなかったものは強制エラーにする
                            //行連結前に置換不能で行連結より置換することができるようになったものまで置換されていたため
                            throw new CodeEE(string.Format(LocalizationManager.Error.CanNotRenameKey, key));
                            //string value = null;
                            //if (!ParserMediator.RenameDic.TryGetValue(key, out value))
                            //    throw new CodeEE("字句解析中に置換(rename)できない符号" + key + "を発見しました");
                            //st.Replace(start, find + 2, value);
                            //continue;//その場から再度解析スタート
                        }
                        ret.Add(new SymbolWord('[')); nestBracketL++; st.ShiftNext(); continue;
                    case ':': ret.Add(new SymbolWord(':')); st.ShiftNext(); continue;
                    case ',':
                        if (endWith == LexEndWith.Comma && nestBracketS == 0)// && (nestBracketL == 0))
                            return;
                        ret.Add(new SymbolWord(',')); st.ShiftNext(); continue;
                    //case '}': ret.Add(new SymbolWT('}')); nestBracketM--; continue;
                    //case '{': ret.Add(new SymbolWT('{')); nestBracketM++; continue;
                    case '\'':
                        if ((flag & LexAnalyzeFlag.AllowSingleQuotationStr) == LexAnalyzeFlag.AllowSingleQuotationStr)
                        {
                            st.ShiftNext();
                            ret.Add(new LiteralStringWord(ReadString(st, StrEndWith.SingleQuotation)));
                            if (st.Current != '\'')
                                throw new CodeEE(string.Format(LocalizationManager.Error.NotClosed, "'"));
                            st.ShiftNext();
                            break;
                        }
                        if ((flag & LexAnalyzeFlag.AnalyzePrintV) != LexAnalyzeFlag.AnalyzePrintV)
                        {
                            //AssignmentStr用特殊処理 代入文の代入演算子を探索中で'=の場合のみ許可
                            if (endWith == LexEndWith.Operator && nestBracketS == 0 && nestBracketL == 0 && st.Next == '=')
                                return;
                            throw new CodeEE(string.Format(LocalizationManager.Error.UnexpectedCharacter, st.Current));
                        }
                        st.ShiftNext();
                        ret.Add(new LiteralStringWord(ReadString(st, StrEndWith.Comma)));
                        if (st.Current == ',')
                            goto case ',';//続きがあるなら,の処理へ。それ以外は行終端のはず
                        return;
                    case '}':
                        if (endWith == LexEndWith.RightCurlyBrace)
                            return;
                        throw new CodeEE(string.Format(LocalizationManager.Error.UnexpectedCharacter, st.Current));
                    case '\"':
                        st.ShiftNext();
                        ret.Add(new LiteralStringWord(ReadString(st, StrEndWith.DoubleQuotation)));
                        if (st.Current != '\"')
                            throw new CodeEE(string.Format(LocalizationManager.Error.NotClosed, "\""));
                        st.ShiftNext();
                        break;
                    case '@':
                        if (st.Next != '\"')
                        {
                            ret.Add(new SymbolWord('@'));
                            st.ShiftNext();
                            continue;
                        }
                        st.ShiftNext();
                        st.ShiftNext();
                        ret.Add(AnalyseFormattedString(st, FormStrEndWith.DoubleQuotation, false));
                        if (st.Current != '\"')
                            throw new CodeEE(string.Format(LocalizationManager.Error.NotClosed, "\""));
                        st.ShiftNext();
                        break;
                    case '.':
                        ret.Add(new SymbolWord('.'));
                        st.ShiftNext();
                        continue;

                    case '\\':
                        if (st.Next != '@')
                            throw new CodeEE(string.Format(LocalizationManager.Error.UnexpectedCharacter, st.Current));
                        {
                            st.Jump(2);
                            ret.Add(new StrFormWord(["", ""], [AnalyseYenAt(st)]));
                        }
                        break;
                    case '{':
                    case '$':
                        throw new CodeEE(string.Format(LocalizationManager.Error.UnexpectedCharacter, st.Current));
                    case ';'://1807 行中コメント
                        if (st.CurrentEqualTo(";#;") && Program.DebugMode)
                        {
                            st.Jump(3);
                            break;
                        }
                        else if (st.CurrentEqualTo(";!;"))
                        {
                            st.Jump(3);
                            break;
                        }
                        st.Seek(0, System.IO.SeekOrigin.End);
                        return;
                    default:
                        {
                            ret.Add(new IdentifierWord(ReadSingleIdentifier(st)));
                            break;
                        }
                }
            }
        }
        local();
        if (nestBracketS != 0 || nestBracketL != 0)
        {
            if (nestBracketS < 0)
                throw new CodeEE(LocalizationManager.Error.NotCloseBrackets);
            else if (nestBracketS > 0)
                throw new CodeEE(LocalizationManager.Error.UnexpectedBrackets);
            if (nestBracketL < 0)
                throw new CodeEE(LocalizationManager.Error.NotCloseSBrackets);
            else if (nestBracketL > 0)
                throw new CodeEE(LocalizationManager.Error.UnexpectedSBrackets);
        }
        if (UseMacro)
            return expandMacro(ret);
        return ret;

    }

    private static WordCollection expandMacro(WordCollection wc)
    {
        //マクロ展開
        wc.PointerReset();
        int count = 0;
        while (!wc.EOL)
        {
            IdentifierWord word = wc.Current as IdentifierWord;
            if (word == null)
            {
                wc.ShiftNext();
                continue;
            }
            string idStr = word.Code;
            DefineMacro macro = GlobalStatic.IdentifierDictionary.GetMacro(idStr);
            if (macro == null)
            {
                wc.ShiftNext();
                continue;
            }
            count++;
            if (count > MAX_EXPAND_MACRO)
                throw new CodeEE(string.Format(LocalizationManager.Error.MacroOverLimit, MAX_EXPAND_MACRO.ToString()));
            if (!macro.HasArguments)
            {
                wc.Remove();
                wc.InsertRange(macro.Statement);
                continue;
            }
            //関数型マクロ
            wc = expandFunctionlikeMacro(macro, wc);
        }
        wc.PointerReset();
        return wc;
    }

    private static WordCollection expandFunctionlikeMacro(DefineMacro macro, WordCollection wc)
    {
        var macroStart = wc.Pointer;
        wc.ShiftNext();
        SymbolWord symbol = wc.Current as SymbolWord;
        if (symbol == null || symbol.Type != '(')
            throw new CodeEE(string.Format(LocalizationManager.Error.MacroHasNotArg, macro.Keyword));
        WordCollection macroWC = macro.Statement.Clone();
        WordCollection[] args = new WordCollection[macro.ArgCount];
        //引数部読み取りループ
        for (int i = 0; i < macro.ArgCount; i++)
        {
            int macroNestBracketS = 0;
            args[i] = new WordCollection();
            while (true)
            {
                wc.ShiftNext();
                if (wc.EOL)
                    throw new CodeEE(string.Format(LocalizationManager.Error.WrongMacroUsage, macro.Keyword));
                symbol = wc.Current as SymbolWord;
                if (symbol == null)
                {
                    args[i].Add(wc.Current);
                    continue;
                }
                switch (symbol.Type)
                {
                    case '(': macroNestBracketS++; break;
                    case ')':
                        if (macroNestBracketS > 0)
                        {
                            macroNestBracketS--;
                            break;
                        }
                        if (i != macro.ArgCount - 1)
                            throw new CodeEE(string.Format(LocalizationManager.Error.MacroDifferentArgCount, macro.Keyword));
                        goto exitfor;
                    case ',':
                        if (macroNestBracketS == 0)
                            goto exitwhile;
                        break;
                }
                args[i].Add(wc.Current);
            }
        exitwhile:
            if (args[i].Collection.Count == 0)
                throw new CodeEE(string.Format(LocalizationManager.Error.CanNotOmitMacroArg, macro.Keyword));
            continue;
        }
    //引数部読み取りループ終端
    exitfor:
        symbol = wc.Current as SymbolWord;
        if (symbol == null || symbol.Type != ')')
            throw new CodeEE(string.Format(LocalizationManager.Error.WrongMacroUsage, macro.Keyword));

        var macroEnd = wc.Pointer;
        wc.Pointer = macroStart;
        while (macroEnd == wc.Pointer)
        {
            wc.Pointer = wc.Pointer.Next;
            wc.Collection.Remove(wc.Pointer.Previous);
        }

        while (!macroWC.EOL)
        {
            MacroWord w = macroWC.Current as MacroWord;
            if (w == null)
            {
                macroWC.ShiftNext();
                continue;
            }
            macroWC.Remove();
            macroWC.InsertRange(args[w.Number]);
            for (int i = 0; i < args[w.Number].Collection.Count; i++)
            {
                macroWC.Pointer = macroWC.Pointer.Next;
            }
        }
        wc.InsertRange(macroWC);
        wc.Pointer = macroStart;
        return wc;
    }

    /// <summary>
    /// @"などの直後からの開始
    /// return時にはendWithの文字がCurrentになっているはず。終端の適切さの検証は呼び出し元が行う。
    /// </summary>
    /// <returns></returns>
    public static StrFormWord AnalyseFormattedString(CharStream st, FormStrEndWith endWith, bool trim)
    {
        List<string> strs = [];
        List<SubWord> SWTs = [];
        //関数が再帰呼び出しを持つため、このバッファはローカル変数である必要があります。
        StringBuilder buffer = new(100);
        while (true)
        {
            char cur = st.Current;
            switch (cur)
            {
                case '\n':
                case '\0':
                    goto end;
                case '\"':
                    if (endWith == FormStrEndWith.DoubleQuotation)
                        goto end;
                    buffer.Append(cur);
                    break;
                case '#':
                    if (endWith == FormStrEndWith.Sharp)
                        goto end;
                    buffer.Append(cur);
                    break;
                case ',':
                    if (endWith == FormStrEndWith.Comma || endWith == FormStrEndWith.LeftParenthesis_Bracket_Comma_Semicolon)
                        goto end;
                    buffer.Append(cur);
                    break;
                case '(':
                case '[':
                case ';':
                    if (endWith == FormStrEndWith.LeftParenthesis_Bracket_Comma_Semicolon)
                        goto end;
                    buffer.Append(cur);
                    break;
                case '%':
                    strs.Add(buffer.ToString());
                    buffer.Clear();
                    st.ShiftNext();
                    SWTs.Add(new PercentSubWord(Analyse(st, LexEndWith.Percent, LexAnalyzeFlag.None)));
                    if (st.Current != '%')
                        throw new CodeEE(string.Format(LocalizationManager.Error.NotFoundCorresponding, "%", "%"));
                    break;
                case '{':
                    strs.Add(buffer.ToString());
                    buffer.Clear();
                    st.ShiftNext();
                    SWTs.Add(new CurlyBraceSubWord(Analyse(st, LexEndWith.RightCurlyBrace, LexAnalyzeFlag.None)));
                    if (st.Current != '}')
                        throw new CodeEE(string.Format(LocalizationManager.Error.NotFoundCorresponding, "{", "}"));
                    break;
                case '*':
                case '+':
                case '=':
                case '/':
                case '$':
                    if (!Config.Config.SystemIgnoreTripleSymbol && st.TripleSymbol())
                    {
                        strs.Add(buffer.ToString());
                        buffer.Clear();
                        st.Jump(3);
                        SWTs.Add(new TripleSymbolSubWord(cur));
                        continue;
                    }
                    else
                        buffer.Append(cur);
                    break;
                case '\\'://エスケープ文字の使用

                    st.ShiftNext();
                    cur = st.Current;
                    switch (cur)
                    {
                        case '\0':
                            throw new CodeEE(LocalizationManager.Error.MissingCharacterAfterEscape);
                        case '\n': break;
                        case 's': buffer.Append(' '); break;
                        case 'S': buffer.Append('　'); break;
                        case 't': buffer.Append('\t'); break;
                        case 'n': buffer.Append('\n'); break;
                        case '@'://\@～～?～～#～～\@
                            {
                                if (endWith == FormStrEndWith.YenAt || endWith == FormStrEndWith.Sharp)
                                    goto end;
                                strs.Add(buffer.ToString());
                                buffer.Clear();
                                st.ShiftNext();
                                SWTs.Add(AnalyseYenAt(st));
                                continue;
                            }
                        default:
                            buffer.Append(cur);
                            st.ShiftNext();
                            continue;
                    }
                    break;
                default:
                    buffer.Append(cur);
                    break;
            }
            st.ShiftNext();
        }
    end:
        strs.Add(buffer.ToString());

        string[] retStr = new string[strs.Count];
        SubWord[] retSWTs = new SubWord[SWTs.Count];
        strs.CopyTo(retStr);
        SWTs.CopyTo(retSWTs);
        if (trim && retStr.Length > 0)
        {
            retStr[0] = retStr[0].TrimStart([' ', '\t']);
            retStr[^1] = retStr[^1].TrimEnd([' ', '\t']);
        }
        return new StrFormWord(retStr, retSWTs);
    }



    /// <summary>
    /// \@直後からの開始、\@の直後がCurrentになる
    /// </summary>
    /// <param name="st"></param>
    /// <returns></returns>
    public static YenAtSubWord AnalyseYenAt(CharStream st)
    {
        WordCollection w = Analyse(st, LexEndWith.Question, LexAnalyzeFlag.None);
        if (st.Current != '?')
            throw new CodeEE(string.Format(LocalizationManager.Error.NotFoundCorresponding, "\\@", "?"));
        st.ShiftNext();
        StrFormWord left = AnalyseFormattedString(st, FormStrEndWith.Sharp, true);
        if (st.Current != '#')
        {
            if (st.Current != '@')
                throw new CodeEE(string.Format(LocalizationManager.Error.NotFoundCorresponding, "\\@", "#"));
            st.ShiftNext();
            ParserMediator.Warn(string.Format(LocalizationManager.Error.NotFoundCorresponding, "\\@", "#"), GlobalStatic.Process.GetScaningLine(), 1, false, false);
            return new YenAtSubWord(w, left, null);
        }
        st.ShiftNext();
        StrFormWord right = AnalyseFormattedString(st, FormStrEndWith.YenAt, true);
        if (st.Current != '@')
            throw new CodeEE(string.Format(LocalizationManager.Error.NotFoundCorresponding, "\\@\',\'?\',\'#", "\\@"));
        st.ShiftNext();
        return new YenAtSubWord(w, left, right);
    }

    #endregion

}